A efkefc file in the directory will not play properly unless the environment supports HDR.

このディレクトリのefkefc のファイルはHDRをサポートしている環境でないと正しく再生できません。
