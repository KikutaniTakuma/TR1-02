The file *_HDR.efkefc will not play properly unless the environment supports HDR.

*_HDR.efkefc のファイルはHDRをサポートしている環境でないと正しく再生できません。
