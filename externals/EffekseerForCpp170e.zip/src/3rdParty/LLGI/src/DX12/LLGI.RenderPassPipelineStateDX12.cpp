#include "LLGI.RenderPassPipelineStateDX12.h"

namespace LLGI
{
} // namespace LLGI
