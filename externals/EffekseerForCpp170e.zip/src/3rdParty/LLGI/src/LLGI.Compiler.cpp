#include "LLGI.Compiler.h"

namespace LLGI
{

void Compiler::Initialize() {}

void Compiler::Compile(CompilerResult& result, const char* code, ShaderStageType shaderStage) {}

} // namespace LLGI
