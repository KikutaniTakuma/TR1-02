
#pragma once

#include "LLGI.Base.h"

namespace LLGI
{

class Shader : public ReferenceObject
{
private:
public:
	Shader() = default;
	~Shader() override = default;
};

} // namespace LLGI
